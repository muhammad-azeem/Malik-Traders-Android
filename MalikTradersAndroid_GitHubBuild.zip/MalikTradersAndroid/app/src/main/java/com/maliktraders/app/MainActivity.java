package com.maliktraders.app;

import android.app.*;
import android.os.Bundle;
import android.content.*;
import android.net.Uri;
import android.provider.DocumentsContract;
import android.database.Cursor;
import android.webkit.*;
import android.print.PrintAttributes;
import android.print.PrintManager;
import android.view.Window;
import android.graphics.Color;
import org.json.*;
import org.xmlpull.v1.XmlPullParser;
import android.util.Xml;

import java.io.*;
import java.text.*;
import java.util.*;
import java.util.zip.*;

public class MainActivity extends Activity {
    private static final int REQ_FOLDER = 3001;
    private WebView webView;
    private Uri folderUri;
    private JSONObject currentData = new JSONObject();
    private SharedPreferences prefs;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        Window w = getWindow();
        w.setStatusBarColor(Color.rgb(7,21,32));
        w.setNavigationBarColor(Color.rgb(7,21,32));
        prefs = getSharedPreferences("malik_traders", MODE_PRIVATE);
        String saved = prefs.getString("folderUri", null);
        if (saved != null) folderUri = Uri.parse(saved);

        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(7,21,32));
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(true);
        webView.addJavascriptInterface(new Bridge(), "Android");
        webView.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView view, String url) { refreshData(false); }
        });
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");
    }

    public class Bridge {
        @JavascriptInterface public void chooseFolder() { runOnUiThread(() -> openFolderPicker()); }
        @JavascriptInterface public void syncNow() { runOnUiThread(() -> refreshData(true)); }
        @JavascriptInterface public String getData() { return currentData.toString(); }
        @JavascriptInterface public String getFolderName() { return folderUri == null ? "Not connected" : "Malik Traders / Excel Records"; }
        @JavascriptInterface public void printPage() { runOnUiThread(() -> printWebView()); }
    }

    private void openFolderPicker() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION | Intent.FLAG_GRANT_PREFIX_URI_PERMISSION);
        startActivityForResult(intent, REQ_FOLDER);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_FOLDER && resultCode == RESULT_OK && data != null) {
            Uri uri = data.getData();
            if (uri != null) {
                final int flags = data.getFlags() & (Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
                try { getContentResolver().takePersistableUriPermission(uri, flags & Intent.FLAG_GRANT_READ_URI_PERMISSION); } catch (Exception ignored) {}
                folderUri = uri;
                prefs.edit().putString("folderUri", uri.toString()).apply();
                refreshData(true);
            }
        }
    }

    private void refreshData(boolean notify) {
        if (folderUri == null) {
            try {
                JSONObject x = new JSONObject();
                x.put("connected", false);
                x.put("lastSync", "Not synced");
                x.put("accounts", new JSONArray());
                currentData = x;
            } catch (Exception ignored) {}
            sendDataToWeb(notify ? "Choose your Google Drive folder first" : null);
            return;
        }
        new Thread(() -> {
            JSONObject result = new JSONObject();
            JSONArray accounts = new JSONArray();
            int files = 0, records = 0;
            try {
                Uri childrenUri = DocumentsContract.buildChildDocumentsUriUsingTree(folderUri, DocumentsContract.getTreeDocumentId(folderUri));
                String[] projection = { DocumentsContract.Document.COLUMN_DOCUMENT_ID, DocumentsContract.Document.COLUMN_DISPLAY_NAME, DocumentsContract.Document.COLUMN_MIME_TYPE, DocumentsContract.Document.COLUMN_LAST_MODIFIED };
                try (Cursor c = getContentResolver().query(childrenUri, projection, null, null, null)) {
                    while (c != null && c.moveToNext()) {
                        String id = c.getString(0);
                        String name = c.getString(1);
                        String mime = c.getString(2);
                        long modified = c.getLong(3);
                        if (name == null) continue;
                        String lower = name.toLowerCase(Locale.ROOT);
                        if (!(lower.endsWith(".xlsx") || lower.endsWith(".xlsm"))) continue;
                        Uri docUri = DocumentsContract.buildDocumentUriUsingTree(folderUri, id);
                        JSONObject acc = parseWorkbook(docUri, name, modified);
                        accounts.put(acc);
                        files++;
                        records += acc.optJSONArray("transactions") == null ? 0 : acc.optJSONArray("transactions").length();
                    }
                }
                double recv=0, pay=0;
                for(int i=0;i<accounts.length();i++) {
                    double b=accounts.getJSONObject(i).optDouble("balance",0);
                    if (b>=0) recv += b; else pay += -b;
                }
                result.put("connected", true);
                result.put("folder", "Malik Traders / Excel Records");
                result.put("lastSync", new SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault()).format(new Date()));
                result.put("fileCount", files);
                result.put("recordCount", records);
                result.put("receivable", recv);
                result.put("payable", pay);
                result.put("net", recv-pay);
                result.put("accounts", accounts);
            } catch (Exception ex) {
                try { result.put("connected", true); result.put("error", ex.getMessage()); result.put("accounts", accounts); } catch(Exception ignored){}
            }
            currentData = result;
            runOnUiThread(() -> sendDataToWeb(notify ? "Sync completed" : null));
        }).start();
    }

    private JSONObject parseWorkbook(Uri uri, String fileName, long modified) throws Exception {
        ArrayList<String> shared = new ArrayList<>();
        byte[] sheetBytes = null;
        byte[] sharedBytes = null;
        try (InputStream raw = getContentResolver().openInputStream(uri); ZipInputStream zin = new ZipInputStream(new BufferedInputStream(raw))) {
            ZipEntry e;
            while ((e = zin.getNextEntry()) != null) {
                String n=e.getName();
                if ("xl/sharedStrings.xml".equals(n)) sharedBytes = readEntry(zin);
                else if ("xl/worksheets/sheet1.xml".equals(n)) sheetBytes = readEntry(zin);
                zin.closeEntry();
            }
        }
        if (sharedBytes != null) shared = parseSharedStrings(sharedBytes);
        if (sheetBytes == null) throw new IOException("No worksheet found");
        ArrayList<ArrayList<String>> rows = parseSheet(sheetBytes, shared);

        int header=-1, dateCol=-1, descCol=-1, debitCol=-1, creditCol=-1, balanceCol=-1;
        for(int r=0;r<Math.min(rows.size(),30);r++) {
            ArrayList<String> row=rows.get(r);
            int score=0;
            for(int c=0;c<row.size();c++) {
                String t=norm(row.get(c));
                if (isDateHeader(t)) { dateCol=c; score++; }
                if (isDescHeader(t)) { descCol=c; score++; }
                if (isDebitHeader(t)) { debitCol=c; score++; }
                if (isCreditHeader(t)) { creditCol=c; score++; }
                if (isBalanceHeader(t)) { balanceCol=c; score++; }
            }
            if(score>=2) { header=r; break; }
        }
        if(header<0) { header=0; dateCol=0; descCol=1; debitCol=2; creditCol=3; balanceCol=4; }

        JSONArray txs=new JSONArray();
        double running=0; boolean sawBalance=false;
        for(int r=header+1;r<rows.size();r++) {
            ArrayList<String> row=rows.get(r);
            String date=get(row,dateCol), desc=get(row,descCol);
            double debit=num(get(row,debitCol)), credit=num(get(row,creditCol));
            String balText=get(row,balanceCol); double balance=num(balText);
            boolean any=!date.trim().isEmpty() || !desc.trim().isEmpty() || debit!=0 || credit!=0 || !balText.trim().isEmpty();
            if(!any) continue;
            if(!balText.trim().isEmpty() && looksNumeric(balText)) { running=balance; sawBalance=true; }
            else running += debit-credit;
            JSONObject t=new JSONObject();
            t.put("date", prettyDate(date));
            t.put("description", desc);
            t.put("debit", debit);
            t.put("credit", credit);
            t.put("balance", running);
            txs.put(t);
        }
        if(!sawBalance) {
            running=0;
            for(int i=0;i<txs.length();i++) { JSONObject t=txs.getJSONObject(i); running += t.optDouble("debit")-t.optDouble("credit"); t.put("balance",running); }
        }
        JSONObject a=new JSONObject();
        String account=fileName.replaceFirst("(?i)\\.(xlsx|xlsm)$","");
        a.put("name", account);
        a.put("fileName", fileName);
        a.put("balance", running);
        a.put("status", running>=0 ? "Receivable" : "Payable");
        a.put("modified", modified>0 ? new SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault()).format(new Date(modified)) : "");
        a.put("transactions", txs);
        return a;
    }

    private byte[] readEntry(InputStream in) throws IOException { ByteArrayOutputStream out=new ByteArrayOutputStream(); byte[] b=new byte[8192]; int n; while((n=in.read(b))>0)out.write(b,0,n); return out.toByteArray(); }
    private ArrayList<String> parseSharedStrings(byte[] bytes) throws Exception {
        ArrayList<String> out=new ArrayList<>(); XmlPullParser p=Xml.newPullParser(); p.setInput(new ByteArrayInputStream(bytes),"UTF-8"); int ev; StringBuilder cur=null;
        while((ev=p.next())!=XmlPullParser.END_DOCUMENT){ if(ev==XmlPullParser.START_TAG && "si".equals(p.getName()))cur=new StringBuilder(); else if(ev==XmlPullParser.TEXT && cur!=null)cur.append(p.getText()); else if(ev==XmlPullParser.END_TAG && "si".equals(p.getName())&&cur!=null){out.add(cur.toString());cur=null;} }
        return out;
    }
    private ArrayList<ArrayList<String>> parseSheet(byte[] bytes, ArrayList<String> shared) throws Exception {
        TreeMap<Integer,TreeMap<Integer,String>> rows=new TreeMap<>(); XmlPullParser p=Xml.newPullParser(); p.setInput(new ByteArrayInputStream(bytes),"UTF-8");
        int ev,row=0,col=0; String type=""; String value=""; boolean inV=false,inT=false;
        while((ev=p.next())!=XmlPullParser.END_DOCUMENT){
            if(ev==XmlPullParser.START_TAG){ String n=p.getName(); if("row".equals(n)){String rr=p.getAttributeValue(null,"r"); row=rr==null?row+1:Integer.parseInt(rr);} else if("c".equals(n)){String ref=p.getAttributeValue(null,"r"); col=cellColumn(ref); type=p.getAttributeValue(null,"t"); value="";} else if("v".equals(n))inV=true; else if("t".equals(n))inT=true; }
            else if(ev==XmlPullParser.TEXT && (inV||inT)) value += p.getText();
            else if(ev==XmlPullParser.END_TAG){ String n=p.getName(); if("v".equals(n))inV=false; else if("t".equals(n))inT=false; else if("c".equals(n)){String v=value; if("s".equals(type)){try{v=shared.get(Integer.parseInt(value));}catch(Exception ignored){}} rows.computeIfAbsent(row,k->new TreeMap<>()).put(col,v);} }
        }
        ArrayList<ArrayList<String>> out=new ArrayList<>();
        for(TreeMap<Integer,String> rr:rows.values()){int max=rr.isEmpty()?0:rr.lastKey(); ArrayList<String> ar=new ArrayList<>(Collections.nCopies(max+1,"")); for(Map.Entry<Integer,String> e:rr.entrySet())ar.set(e.getKey(),e.getValue()); out.add(ar);} return out;
    }
    private int cellColumn(String ref){ if(ref==null)return 0; int c=0; for(char ch:ref.toCharArray()){if(ch>='A'&&ch<='Z')c=c*26+(ch-'A'+1); else if(ch>='a'&&ch<='z')c=c*26+(ch-'a'+1); else break;} return Math.max(0,c-1); }
    private String get(ArrayList<String> r,int c){return c>=0&&c<r.size()?r.get(c):"";}
    private String norm(String s){return s==null?"":s.trim().toLowerCase(Locale.ROOT).replace(".","");}
    private boolean isDateHeader(String s){return s.equals("date")||s.contains("date");}
    private boolean isDescHeader(String s){return s.contains("description")||s.contains("particular")||s.contains("detail")||s.contains("narration");}
    private boolean isDebitHeader(String s){return s.equals("dr")||s.contains("debit")||s.startsWith("dr ");}
    private boolean isCreditHeader(String s){return s.equals("cr")||s.contains("credit")||s.startsWith("cr ");}
    private boolean isBalanceHeader(String s){return s.contains("balance")||s.contains("closing");}
    private boolean looksNumeric(String s){return s!=null&&s.replaceAll("[^0-9.-]","").matches("-?\\d+(\\.\\d+)?");}
    private double num(String s){ if(s==null)return 0; try{return Double.parseDouble(s.replace(",","").replace("PKR","").replace("Rs.","").replace("Rs","").trim());}catch(Exception e){return 0;} }
    private String prettyDate(String s){ if(s==null)return ""; try{ double d=Double.parseDouble(s); if(d>20000&&d<80000){ long ms=(long)((d-25569d)*86400000d); return new SimpleDateFormat("dd MMM yyyy",Locale.getDefault()).format(new Date(ms)); } }catch(Exception ignored){} return s; }

    private void sendDataToWeb(String toast) {
        String js="window.receiveNativeData("+JSONObject.quote(currentData.toString())+")" + (toast==null?"":";window.showToast("+JSONObject.quote(toast)+")") + ";";
        webView.evaluateJavascript(js,null);
    }
    private void printWebView() {
        PrintManager pm=(PrintManager)getSystemService(PRINT_SERVICE);
        pm.print("Malik Traders Report", webView.createPrintDocumentAdapter("Malik Traders Report"), new PrintAttributes.Builder().build());
    }
}
