Malik Traders Android App
=========================

Purpose
- Read-only Android viewer for Malik Traders Excel accounting files.
- Excel remains the single source of truth. Data entry happens only on the laptop.
- On Android, select the Google Drive folder containing the .xlsx/.xlsm files.
- The app remembers the selected folder and reads the latest files whenever Sync Now is tapped.

Main screens
- Dashboard: Total Receivable, Total Payable, Net Position, Active Accounts, Total Records, Top Accounts, Recent Updates.
- Accounts: search/filter accounts and open customer ledgers.
- Search: search accounts and transaction content.
- Reports: business summary, balance visualization, Print / Save PDF.
- Settings: select Drive folder, Sync Now, last sync, read-only status.

Important
- There are NO Debit Turnover or Credit Turnover cards/metrics in this version.
- The app does not write to or modify Excel files.
- It parses the first worksheet of each .xlsx/.xlsm file and auto-detects common columns such as Date, Description/Particulars, Debit/Dr, Credit/Cr, Balance.

Build
1. Open this project in Android Studio Ladybug or newer.
2. Allow Gradle sync.
3. Build > Build APK(s).
4. The debug APK will be under app/build/outputs/apk/debug/app-debug.apk.

Google Drive use
- Install/sign into Google Drive on the Android phone.
- In the app: Settings > Choose > select the Malik Traders folder shown by the Android system file picker.
- Android persists read-only permission to that folder.
